#include <unistd.h>
struct MemoryChunk {
    void * address;
    size_t size;
};