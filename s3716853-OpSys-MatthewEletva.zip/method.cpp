enum Method{
    FIRST,
    WORST,
    BEST
};